"""
54) Write a Python program to check multiple keys exists in a dictionary
Ans : 1.Using all() and Generator Expression
      2.Using a Loop
      3.Using Set Operations"""

#1.Using all() and Generator Expression

my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

keys_to_check = ['a', 'b', 'e']

if all(key in my_dict for key in keys_to_check):
    print("All keys are present in the dictionary.")
else:
    print("Not all keys are present in the dictionary.")

#2.using loop

my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
keys_to_check = ['a', 'b', 'e']

all_keys_present = True

for key in keys_to_check:
    if key not in my_dict:
        all_keys_present = False
        break

if all_keys_present:
    print("All keys are present in the dictionary.")
else:
    print("Not all keys are present in the dictionary.")


#3 using set operations
my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

keys_to_check = ['a', 'b', 'e']

dict_keys = set(my_dict.keys())
keys_set = set(keys_to_check)

if keys_set.issubset(dict_keys):
    print("All keys are present in the dictionary.")
else:
    print("Not all keys are present in the dictionary.")
