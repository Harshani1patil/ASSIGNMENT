"""

66) How can you pick a random item from a list or tuple? 
Ans :"""

import random


my_list = [1, 2, 3, 4, 5]
random_item_from_list = random.choice(my_list)
print(random_item_from_list)

my_tuple = ('apple', 'banana', 'cherry')
random_item_from_tuple = random.choice(my_tuple)
print(random_item_from_tuple)