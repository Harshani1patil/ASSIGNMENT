"""
85) When will the else part of try-except-else be executed?
Ans :The else part of a try-except-else block in Python is executed only if no exception is raised in the try block.
"""
try:

    num = int(input("Enter a number: "))
    result = 10 / num
except ZeroDivisionError:
    print("Error: Cannot divide by zero.")
except ValueError:
    print("Error: Invalid input, please enter a number.")
else:
    print(f"The result is {result}")
finally:
    print("Execution complete.")
