"""
47) How will you create a dictionary using tuples in python? 
Ans :"""
tuples = [("apple", 1), ("banana", 2), ("cherry", 3)]

my_dict = dict(tuples)

print(my_dict)