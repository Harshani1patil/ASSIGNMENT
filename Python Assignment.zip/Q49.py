"""
49) Write a Python script to concatenate following dictionaries to create 
a new one.
Ans :"""

dict1 = {"a": 1, "b": 2}
dict2 = {"c": 3, "d": 4}
dict3 = {"e": 5, "f": 6}


dict1.update(dict2)
dict1.update(dict3)

print("Concatenated dictionary:", dict1)