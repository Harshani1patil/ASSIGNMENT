"""
(2) What is programing?
Ans : 
    Programming is the process of creating a set of instructions that a computer can understand and execute to perform specific tasks.
 It involves writing code in various programming languages, which serve as a medium for expressing the logic and functionality of a 
 program

"""