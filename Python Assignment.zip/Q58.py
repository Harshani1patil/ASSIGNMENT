"""
58) Write a Python program to combine values in python list of dictionaries. 
Sample data: [{'item': 'item1', 'amount': 400}, {'item': 'item2', 'amount': 
300}, o {'item': 'item1', 'amount': 750}] 
Expected Output: 
• Counter ({'item1': 1150, 'item2': 300})
Ans :"""

from collections import defaultdict
data = [
    {'item': 'item1', 'amount': 400},
    {'item': 'item2', 'amount': 300},
    {'item': 'item1', 'amount': 750}
]


result = defaultdict(int)


for entry in data:
    item = entry['item']
    amount = entry['amount']
    result[item] += amount


result_dict = dict(result)

print(f"Counter ({result_dict})")