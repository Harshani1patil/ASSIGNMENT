"""
(3) What is Python?

Ans : Python is a high-level, interpreted programming language known for its readability and simplicity.
 Created by Guido van Rossum and first released in 1991, Python has become one of the most popular programming languages in the world.

"""