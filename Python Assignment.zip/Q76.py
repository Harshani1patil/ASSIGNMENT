"""
76) Write a Python program to read a file line by line and store it into a list 
Ans :"""

def read_file_to_list(filename):
    lines = []
    with open(filename, 'r') as file:
    
        for line in file:
            lines.append(line.strip())  
    return lines

filename = 'example.txt'
lines = read_file_to_list(filename)

for line in lines:
    print(line)
