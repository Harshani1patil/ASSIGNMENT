"""
26) How will you remove last object from a list?
Ans : pop(): Removes the last element and optionally returns it.
      remove(): Removes a specific value (not ideal for removing the last item unless you know its value).

"""
##using Pop() fumction.

my_list = [10, 20, 30, 40, 50]
last_item = my_list.pop()
print("Updated List:", my_list)  
print("Removed Item:", last_item)


#using Remove() function.

my_list = [10, 20, 30, 40, 50]
my_list.remove(50)
print("Updated List:", my_list)
    

