"""
71) What is File function in python? What are keywords to create 
and write file. 
Ans : n Python, file handling is done through the built-in open() function, which allows you to create, read, write, and manipulate files.
      The open() function returns a file object that can be used to interact with the file."""

 #Key Steps in File Handling:
"""
    1.Opening a File
    2.Reading or Writing to a File
    3.Closing the File
"""
#Keywords to Create and Write a File

# Create and write to a file
with open('sample.txt', 'w') as file:
    file.write("This is the first line.\n")
    file.write("This is the second line.\n")

# Read the content of the file
with open('sample.txt', 'r') as file:
    content = file.read()
    print(content)
