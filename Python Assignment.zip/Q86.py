"""
86) Can one block of except statements handle multiple exception?
Ans :Yes, a single except block can handle multiple exceptions in Python. You can do this by specifying a tuple of exceptions in a single except clause. 
If any of the exceptions in the tuple are raised, the except block will handle them.
"""
try:
    x = int(input("Enter a number: "))
    result = 10 / x
except (ZeroDivisionError, ValueError) as e:
    if isinstance(e, ZeroDivisionError):
        print("Error: Cannot divide by zero!")
    elif isinstance(e, ValueError):
        print("Error: Invalid input! Please enter a valid number.")
