"""
18) Write a Python program to count occurrences of a substring in a string. 
Ans :"""

def count_substring_occurrences(main_string, substring):
    return main_string.count(substring)

main_string = "hello world, hello universe, hello galaxy"
substring = "hello"

occurrences = count_substring_occurrences(main_string, substring)
print(f"The substring '{substring}' appears {occurrences} times in the string.")