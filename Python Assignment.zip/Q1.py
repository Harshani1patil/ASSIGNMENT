"""
(1) What are the types of Applications? 
Ans : 

Applications may be categorized into different types considering their functionality, deployment as well as the platform through which they run.
These are some of the very common types:

1.Web Applications:

Run on web browsers.
Examples: Bank websites, e-commerce websites, social media websites.

2.Mobile Applications:

Designed for smartphones and tabs.
Examples: Instagram, WhatsApp, mobile games

3.Desktop Applications:

Installed on personal computers
Examples: Microsoft Office, Adobe Photoshop


4.Enterprise Applications:

Served to organizational needs
Examples: CRM software, ERP systems.

"""