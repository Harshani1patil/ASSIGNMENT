"""
80) Write a Python program to count the frequency of words in a file.
Ans :"""

from collections import Counter
import string

def count_word_frequency(filename):
    try:
        with open(filename, 'r') as file:
            text = file.read() 

        text = text.translate(str.maketrans('', '', string.punctuation)).lower()
        words = text.split()
        word_count = Counter(words)

        return word_count
    except FileNotFoundError:
        return "The file does not exist."
    except Exception as e:
        return str(e)


filename = 'example.txt' 
word_count = count_word_frequency(filename)


if isinstance(word_count, dict):
    print(f"Word frequencies in the file '{filename}':")
    for word, count in word_count.items():
        print(f"'{word}': {count}")
else:
    print(word_count)
