"""
79) Write a Python program to count the number of lines in a text file.
Ans :"""
def count_lines_in_file(filename):
    try:
        with open(filename, 'r') as file:

            line_count = sum(1 for line in file)
        return line_count
    except FileNotFoundError:
        return "The file does not exist."
    except Exception as e:
        return str(e)


filename = 'example.txt'  
line_count = count_lines_in_file(filename)

print(f"The number of lines in the file '{filename}' is: {line_count}")
