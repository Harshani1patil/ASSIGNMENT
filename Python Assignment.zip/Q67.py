"""
67) How can you pick a random item from a range?
Ans : """
import random

r = range(1, 11) 
random_item = random.choice(list(r))

print(random_item)