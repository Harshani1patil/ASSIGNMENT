"""

89) How Do You Handle Exceptions with Try/Except/Finally in Python? 
Explain with coding snippets.
Ans :In Python, exceptions are handled using the try, except, and finally blocks. This provides a way to gracefully manage errors and ensure
     that certain code is executed, regardless of whether an error occurs or not.
"""
try:
    x = 10 / 2
    file = open("example.txt", "w")
    file.write("Hello, world!")
except ZeroDivisionError:
    print("Cannot divide by zero!")
except IOError:
    print("File error occurred!")
finally:
    print("Cleaning up...")
    try:
        file.close() 
    except NameError:
        pass 
