"""
44) Write a Python program to create a tuple with different data types.
Ans :"""
my_tuple = (25, "Hello", 3.14, [1, 2, 3], {"key": "value"}, (1, 2))


print("Tuple with different data types:", my_tuple)
print("Integer:", my_tuple[0])
print("String:", my_tuple[1])
print("Float:", my_tuple[2])
print("List:", my_tuple[3])
print("Dictionary:", my_tuple[4])
print("Nested Tuple:", my_tuple[5])