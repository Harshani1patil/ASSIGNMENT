"""
51) How Do You Traverse Through a Dictionary Object in Python?
Ans : iterate over the dictionary keys using a for loop. By default, when you iterate through a dictionary, it will give you the keys.
    iterate over just the values in the dictionary, you can use my_dict.values()"""

#over keys
my_dict = {'a': 1, 'b': 2, 'c': 3}

for key in my_dict:
    print(key)


#over values
for value in my_dict.values():
    print(value)