"""
59) Write a Python program to create a dictionary from a string. 
Note: Track the count of the letters from the string.
Ans :"""

input_string = "abracadabra"

letter_count = {}

for letter in input_string:
    if letter in letter_count:
        letter_count[letter] += 1  
    else:
        letter_count[letter] = 1 

print(letter_count)
