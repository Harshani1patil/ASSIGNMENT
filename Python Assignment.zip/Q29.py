"""
29) Write a Python function to get the largest number, smallest num 
and sum of all from a list.
Ans :"""

def get_list_info(my_list):
    if not my_list:
        return None, None, 0 

    largest = max(my_list)
    
    smallest = min(my_list)
    
    total_sum = sum(my_list)
    
    return largest, smallest, total_sum

my_list = [12, 45, 7, 34, 89, 23, 56]
largest, smallest, total_sum = get_list_info(my_list)

print("Largest number:", largest)
print("Smallest number:", smallest)
print("Sum of all numbers:", total_sum)