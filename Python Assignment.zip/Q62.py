"""
62) Write a Python function to check whether a number is in a given range 
Ans :"""

def is_in_range(number, start, end):
    return start <= number <= end

#5 in the range
print(is_in_range(5, 1, 10))  

#0 is not in range
print(is_in_range(0, 1, 10)) 

#10 in  range
print(is_in_range(10, 1, 10))