"""
32) Write a Python program to remove duplicates from a list. 
Ans : set() function automatically removes duplicates because a set in Python only allows unique values"""

def remove_duplicates_using_set(my_list):
    return list(set(my_list))

my_list = [1, 2, 2, 3, 4, 4, 5]
result = remove_duplicates_using_set(my_list)
print("List after removing duplicates:", result)