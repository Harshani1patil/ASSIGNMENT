"""
30) How will you compare two lists?
Ans :  if two lists are equal, you can use the == operator. 

"""

list1 = [1, 2, 3, 4]
list2 = [1, 2, 3, 4]

print(list1 == list2)
