"""
81) Write a Python program to write a list to a file.
Ans : """


my_list = ['apple', 'banana', 'cherry', 'date', 'elderberry']


file_name = 'output.txt'


with open(file_name, 'w') as file:
    for item in my_list:
        file.write(item + '\n')

print(f"List has been written to {file_name}")
