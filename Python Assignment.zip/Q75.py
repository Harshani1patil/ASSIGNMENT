"""
75) Write a Python program to read last n lines of a file. 
Ans :"""
from collections import deque

def read_last_n_lines(filename, n):
   
    with open(filename, 'r') as file:
  
        last_n_lines = deque(file, maxlen=n)
    

    for line in last_n_lines:
        print(line.strip())


filename = 'example.txt'
n = 5 
read_last_n_lines(filename, n)