"""
9) Write python program that swap two number with temp variable 
and without temp variable.
Ans :"""
def swap_with_temp(a, b):
    temp = a 
    a = b    
    b = temp  
    return a, b


def swap_without_temp(a, b):
    a = a + b  
    b = a - b  
    a = a - b  
    return a, b

try:
    a = int(input("Enter the first number: "))
    b = int(input("Enter the second number: "))
    
    
    a1, b1 = swap_with_temp(a, b)
    print(f"After swapping with temp variable: a = {a1}, b = {b1}")
    
   
    a2, b2 = swap_without_temp(a, b)
    print(f"After swapping without temp variable: a = {a2}, b = {b2}")
    
except ValueError:
    print("Please enter valid integers.")


