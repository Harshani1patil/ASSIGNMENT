"""
88) What happens when „1‟== 1 is executed?
Ans :false"""

#"1" is a string 
# 1 is an integer 
#Python does not perform type coercion when using the == operator. It requires both operands to be of the same type to return True

#false
"1" == 1  # False

#true
int("1") == 1 
