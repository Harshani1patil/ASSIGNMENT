"""
42) Write a Python program to split a list into different variables. 
Ans :"""

def split_list_into_variables(my_list):
    var1, var2, var3 = my_list
    return var1, var2, var3

my_list = [10, 20, 30]
var1, var2, var3 = split_list_into_variables(my_list)

print(f"var1 = {var1}")
print(f"var2 = {var2}")
print(f"var3 = {var3}")