"""
53) Write a Python script to print a dictionary where the keys are 
numbers between 1 and 15.
Ans :"""

my_dict = {i: i**2 for i in range(1, 16)}
print(my_dict)