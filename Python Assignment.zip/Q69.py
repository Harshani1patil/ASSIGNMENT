"""
69) How will you set the starting value in generating random numbers? 
Ans : 

"""
#In Python, you can set the starting value (or seed) for generating random numbers using the random.seed() function

import random

random.seed(42)

print(random.randint(1, 100))  
print(random.random())        
print(random.choice([10, 20, 30, 40]))  
