"""
77) Write a Python program to read a file line by line store it into a variable.
Ans :"""
def read_file_to_variable(filename):
    content = ""  
 
    with open(filename, 'r') as file:
       
        for line in file:
            content += line  
    return content


filename = 'example.txt'
file_content = read_file_to_variable(filename)

print(file_content)
