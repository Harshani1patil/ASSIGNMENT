"""

65) How Many Basic Types of Functions Are Available in Python? 
Ans : There is two type of functions 
        1. in built functions 
        2.user defined functions"""

#Built-in Functions:
"""
These are the functions that are provided by Python itself and are available by default. They perform common operations and can be used directly without any need for import.
Examples include functions like print(), len(), sum(), max(), abs(), and many more.

"""

#user defined functions

"""
These are functions that you create by defining them using the def keyword (or using lambda for anonymous functions).
A user-defined function is used to encapsulate reusable code and can accept parameters and return values as needed.
"""

#ex.
def my_function(x, y):
    return x + y


#ex
def greet(name):
    return f"Hello, {name}!"

print(greet("Alice"))