"""
15) Write a Python program to calculate the length of a string.
Ans :"""
def string_length(s):
    return len(s) 

user_input = input("Enter a string: ")
length = string_length(user_input)
print(f"The length of the string is: {length}")