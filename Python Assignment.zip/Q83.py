"""
83) Explain Exception handling? What is an Error in Python?
Ans : Exception handling is a mechanism in Python (and most programming languages) that allows you to handle errors gracefully during runtime, without crashing 
    the program. Instead of having your program terminate abruptly when an error occurs, you can anticipate potential issues and provide custom behavior for
    those situations.

    In Python, exceptions are handled using the try, except, else, and finally blocks.
    You write the code that might raise an exception inside the try block. If an error occurs within this block, the rest of the code in the block is skipped,
    and Python jumps to the corresponding except block.except block: If an exception is raised in the try block, Python looks for a matching except block to handle 
    that exception. You can specify the type of exception you're expecting, or use a general except to catch any exception.else block: This block is optional and runs
    only if no exception occurs in the try block. It's useful for code that should execute when no errors are raised.finally block: This block is also optional and
     always executes, regardless of whether an exception was raised or not. It is commonly used for cleanup activities (e.g., closing files or releasing resources).

"""
try:

    result = 10 / 0
except ZeroDivisionError as e:
    print(f"Error: {e}")
else:
    print("Division successful!")
finally:
    print("Cleaning up resources...")


#Types of Errors
"""
Syntax Errors (or Parsing Errors): These occur when the Python code is not written correctly according to the language rules.
These errors are detected by the Python interpreter before execution starts.

"""

print("Hello, World!"  

#Runtime Errors
"""
These occur while the program is running. These errors are not detected by the interpreter ahead of time, and
 they cause the program to crash unless handled properly using exception handling.

"""
"""
Common runtime errors (exceptions) include:

ZeroDivisionError : Raised when dividing by zero.
FileNotFoundError : Raised when trying to open a file that doesn't exist.
ValueError        : Raised when a function receives an argument of the correct type, but with an inappropriate value.
TypeError         : Raised when an operation is performed on an object of an inappropriate type (e.g., trying to add a string to an integer).
IndexError        : Raised when trying to access an element of a list with an invalid index.
KeyError          : Raised when trying to access a dictionary with a key that doesn't exist.

"""

numbers = [1, 2, 3]
print(numbers[5]) 
