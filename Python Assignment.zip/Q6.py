
"""
6)Write a Python program to get the Fibonacci series of given range. 
Ans :"""

def fibonacci_series(n):
    fib_series = []
    a, b = 0, 1
    while a <= n:
        fib_series.append(a)
        a, b = b, a + b
    return fib_series

# Input: Getting the range from the user
try:
    num = int(input("Enter the range up to which you want the Fibonacci series: "))
    
    if num < 0:
        print("Please enter a non-negative number.")
    else:
        # Generate and display the Fibonacci series up to the given number
        fib_series = fibonacci_series(num)
        print(f"Fibonacci series up to {num}: {fib_series}")
        
except ValueError:
    print("Please enter a valid integer.")