"""
38) Write a Python program to select an item randomly from a list. 
Ans :"""

import random

def select_random_item(my_list):
    return random.choice(my_list)
    
my_list = ['apple', 'banana', 'cherry', 'date', 'elderberry']
random_item = select_random_item(my_list)
print(f"Randomly selected item: {random_item}")